A Pen created at CodePen.io. You can find this one at https://codepen.io/azureknight/pen/ypicK.

 Just a random Login Page designed with Flat UI in mind. Thank you @chriscoyier for the css arrow inspiration and wisdom. Really appreciate it.